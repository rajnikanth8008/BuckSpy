package com.rajnikanth.app.buckspy.dao;

import androidx.room.Dao;
import androidx.room.Insert;

import com.rajnikanth.app.buckspy.entity.ExpenseDetails;

@Dao
public interface ExpenseDetailsDao  {
    @Insert
    void insert(ExpenseDetails expenseDetails);
}
