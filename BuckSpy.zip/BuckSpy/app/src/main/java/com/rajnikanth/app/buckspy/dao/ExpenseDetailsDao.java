package com.rajnikanth.app.buckspy.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;

import com.rajnikanth.app.buckspy.entity.ExpenseDetails;
@Dao
public interface ExpenseDetailsDao  {
    @Insert
    void insert(ExpenseDetails expenseDetails);
}
