package com.rajnikanth.app.buckspy.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.rajnikanth.app.buckspy.MainActivity;
import com.rajnikanth.app.buckspy.R;
import com.rajnikanth.app.buckspy.location.MyItem;


@SuppressLint("ValidFragment")
public class PlacesFragment extends Fragment {

    Activity context = null;
    private ClusterManager<MyItem> mClusterManager;

    public PlacesFragment(MainActivity mainActivity) {
        this.context = mainActivity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = getLayoutInflater().inflate(R.layout.fragment_places, container, false);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }


}
