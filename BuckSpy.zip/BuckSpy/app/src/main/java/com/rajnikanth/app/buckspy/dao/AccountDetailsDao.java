package com.rajnikanth.app.buckspy.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.rajnikanth.app.buckspy.entity.AccountDetails;

import java.util.List;

@Dao
public interface AccountDetailsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(AccountDetails... accountDetails);

    @Query("Select * FROM AccountDetails")
    public List<AccountDetails> loadAll();

}
