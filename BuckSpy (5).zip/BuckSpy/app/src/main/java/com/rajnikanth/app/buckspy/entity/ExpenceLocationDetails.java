package com.rajnikanth.app.buckspy.entity;

public class ExpenceLocationDetails {
    public String image_path;
    public String expence_location;
    public String category_name;

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public String getExpence_location() {
        return expence_location;
    }

    public void setExpence_location(String expence_location) {
        this.expence_location = expence_location;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
}
